#include "Movement.h"
#include "UltraDistanceSensor.h"
#include "LineTracking.h"



class MapAlgorithm 
{
  /*Variables to define the bitwise values of either directions*/
  uint8_t north=1;  
  uint8_t south=2;
  uint8_t east=4;
  uint8_t west=8;
  
  uint8_t matrix[4][4]={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}}; //2D array to tell if there is a wall on a certain side of the cell
  int newMatrix[4][4]={{1,1,1,1},{1,1,1,1},{1,1,1,1},{1,1,1,1}};//2D array to store the values of the distance from each cell tot eh goal cell
  
  /*variables to tell if there is  wall on a specific side of the cell*/
  bool westWall=false;  
  bool northWall=false;
  bool eastWall=false;
  bool southWall=false;
  
  public:
    int x=0; 
    int y=0;
    int rightDist=0;  //store the distance between the car and an obstacle on its right hand side
    int leftDist=0; //stores the dstance between the car and an obstacle on its left hand side
    int middleDist=0; //stores the distance between the car and an obstacle infront of it
    int heading=0;   //store sthe angular direction to which the the car is moving to
    void scanCell();  //scans the cell to get rid of any out of bounds positions
    void addWall();  //stores the information of the existance of a wall on any side of the cell
    int floodFill();  //loops through the entire cells to update the distance between the cells and the goal cell
    bool checkWestWall();
    bool checkNorthWall();
    bool checkEastWall();
    bool checkSouthWall();
    void motionAlgorithm();
};

class Car{
  Movement carMovement;
  LineTracking lineTracking;
  UltraDistanceSensor ultraDistanceSensor;
  MapAlgorithm mapAlgorithm;
  int carState=1;
  int goalX=3;
  int goalY=3;
  public:
    virtual void motionAlgorithm(); //implements the mapAlgorithm functionality to generate a route
    void setup();
    void run();
    void updatePosition();
  
};
