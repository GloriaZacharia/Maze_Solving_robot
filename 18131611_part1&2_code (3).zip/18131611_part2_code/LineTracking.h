#define LT_R !digitalRead(10)
#define LT_M !digitalRead(4)
#define LT_L !digitalRead(2)
#include"Arduino.h"
#define JUNCTION 4
class LineTracking{
  public:
    int detectLine();
};
