#include<Servo.h>
#include "Arduino.h"

#define Echo  A4
#define Trig  A5

const int LEFT=1;
const int FORWARD =2;
const int RIGHT =3;
const int BACK =4;

class UltraDistanceSensor
{
  Servo myServo;
  int password=0;
  public:
    int rightDistance = 0, leftDistance = 0, middleDistance = 0;
    void attachServo();
    int measureDistance();
    void scanDistance();
};
