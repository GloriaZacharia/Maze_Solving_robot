#include "UltraDistanceSensor.h"


int UltraDistanceSensor::measureDistance()
{
  digitalWrite(Trig, LOW);   
  delayMicroseconds(2);
  digitalWrite(Trig, HIGH);  
  delayMicroseconds(20);
  digitalWrite(Trig, LOW);   
  float Fdistance = pulseIn(Echo, HIGH); 
  Serial.print("Time=");
  Serial.println(Fdistance); 
  Fdistance= Fdistance*(0.034/2);       
  return (int)Fdistance;
}
void UltraDistanceSensor::scanDistance()
{
    //delay(500);
    myServo.write(75);  //setservo position according to scaled value
    delay(500); 
    middleDistance = measureDistance();
    Serial.print("Middle distance=");
    Serial.println(middleDistance);

    if(middleDistance <= 20) {     
      //stop();
      delay(500); 
      myServo.write(8);          
      delay(1000);      
      rightDistance = measureDistance();
      Serial.print("Right distance=");
      Serial.println(rightDistance);
      
      delay(500);
      myServo.write(75);      
      delay(1000);                                                  
      myServo.write(150);              
      delay(1000); 
      leftDistance = measureDistance();
      Serial.print("Left distance=");
      Serial.println(leftDistance);

      delay(500);
      myServo.write(75);              
      delay(1000);
      if(rightDistance > leftDistance) {
        if(rightDistance <= 20)
        {
          return BACK;
        }
        else{
         return RIGHT;
        }
        
      }
      else if(rightDistance < leftDistance) {
        if(leftDistance <= 20)
        {
          return BACK;
        }
        else{
          return LEFT;
        }
      }
      else {
        return BACK;
      }
    }
    else {
        return FORWARD;
      }  
                
}

void UltraDistanceSensor::attachServo()
{
  myServo.attach(3);
}
