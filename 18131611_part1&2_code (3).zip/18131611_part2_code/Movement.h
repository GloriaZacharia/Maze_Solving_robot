#include "Arduino.h"
#define ENA 5
#define ENB 6
#define IN1 7
#define IN2 8
#define IN3 9
#define IN4 11

#define turningSpeed 500

class Movement{
  public:
    int carSpeed= 150;
    void back();
    void forward();
    void left();
    void right();
    void stop();
    
};
