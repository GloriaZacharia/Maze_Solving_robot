#include "LineTracking.h"


int LineTracking::detectLine()
{
  if((!LT_L)&&(LT_M)&&(!LT_R))
  {
    return LT_M;
  }
  if((LT_L) && (LT_M) && (!LT_R))
  {
    return LT_L;
  }
  if((LT_L) && (!LT_M)&& (!LT_R))
  {
    return LT_L;
  }
  if((!LT_L) && (LT_M) &&(LT_R))
  {
    return LT_R;
  }
  if((!LT_L) && (!LT_M) && (LT_R))
  {
    return LT_R;
  }
  if((LT_L)&&(LT_M)&&(LT_R))
  {
    return JUNCTION;
  }
}
