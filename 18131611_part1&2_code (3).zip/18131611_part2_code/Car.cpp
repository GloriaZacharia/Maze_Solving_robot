
#include "Car.h"
#include <math.h>
#include<stdint.h>

void Car::run()
{
  int dir=lineTracking.detectLine();
  if(dir==LT_M){
    carMovement.forward();
  }
  else if(dir==LT_R) { 
    carMovement.right();                     
    while(LT_R);
  }   
  else if(dir==LT_L) {
    carMovement.left();
    while(LT_L);
  }
  else if(dir ==JUNCTION) //If the car has moved to a new cell or in other words it has reached a junction
  {
    carMovement.stop();
    delay(500);
    //carMovement.carSpeed=170;
    carMovement.forward();
    delay(100);
    carMovement.carSpeed=150;
    carMovement.stop();
    delay(360);
    ultraDistanceSensor.attachServo();
    ultraDistanceSensor.scanDistance();
    mapAlgorithm.rightDist=ultraDistanceSensor.rightDistance;
    mapAlgorithm.leftDist=ultraDistanceSensor.leftDistance;
    mapAlgorithm.middleDist=ultraDistanceSensor.middleDistance;
    
    motionAlgorithm(); //perform cell calculations to determine the best next position of the car

    if(mapAlgorithm.heading==270)//If the angular value indicates a north
    {
      carMovement.forward(); //move the car forward
      
    }
    else if(mapAlgorithm.heading==90) //if the angular value indicates a south
    {
      carMovement.back();  //move the car backwards
      delay(360);
    }
    else if(mapAlgorithm.heading==0) //if the angular value indicates an east
    {
      carMovement.right(); //take a right turn
      delay(500);
    }
    else if(mapAlgorithm.heading==180) //if the angualar value indicates a west
    {
      carMovement.left();  //take a left turn
      delay(600);
    }
    updatePosition(); //calculate the car's new position and update it
    if(carState==0) //if the goal is reached
    {
       while(true)  //stop the car and the pathe finding process
      {
         Serial.print("Finished ");
        carMovement.stop();
      }
    }
  }
  
}
void Car::motionAlgorithm()
{
  mapAlgorithm.motionAlgorithm();
}
void Car::setup()
{
    Serial.begin(9600); 
    pinMode(IN1,OUTPUT);//before useing io pin, pin mode must be set first 
    pinMode(IN2,OUTPUT);
    pinMode(IN3,OUTPUT);
    pinMode(IN4,OUTPUT);
    pinMode(ENA,OUTPUT);
    pinMode(ENB,OUTPUT);

    pinMode(LT_R,INPUT);
    pinMode(LT_M,INPUT);
    pinMode(LT_L,INPUT);
    
    pinMode(Echo, INPUT);    
    pinMode(Trig, OUTPUT); 
}

void MapAlgorithm::scanCell()
{
  int k=x+1, m=y; //get the horizontal and vertical position values of the front neighbour of the current cell
  if((k || m)<0) //if either of the values is less than 0
  {
    northWall=true; //declare a wall in that direction
  }
  k=x;
  m=y+1; //get the horizontal and vertical position values of the left side neighbour of the current cell
  if(k||m<0)//if either of the values is less than 0
  {
    westWall=true;//declare a wall in that direction
  }
  k=x-1;//get the horizontal and vertical position values of the right side neighbour of the current cell
  m=y;
  if(k||m<0)//if either of the values is less than 0
  {
    southWall=true;//declare a wall in that direction
  }
  k=x;//get the horizontal and vertical position values of the right side neighbour of the current cell
  m=y-1;
  if(k||m<0)//if either of the values is less than 0
  {
    eastWall=true;//declare a wall in that direction
  }
}
void MapAlgorithm::addWall()
{
  if(leftDist<=20) //if the distance between the car and an obstacle on the left side of the car is less than 20
  {
    westWall=true;//declare a wall in that direction
  }
  if(rightDist<=20)//if the distance between the car and an obstacle on the right side of the car is less than 20
  {
     eastWall=true;//declare a wall in that direction
  }
  if(middleDist<=20)//if the distance between the car and an obstacle infornt of it is less than 20
  {
     northWall=true;//declare a wall in that direction
  }

  if(northWall==false) //if there is a wall infront of the car
  {
    matrix[x+1][y]=matrix[x+1][y]|north; //update the 2D array with a 1 to indicate the existance of a wall infront of the car
  }
  if(southWall==false)//if there is a wall behind the car
  {
    matrix[x-1][y]=matrix[x-1][y]|south;//update the 2D array with a 1 to indicate the existance of a wall behind of the car
  }
  if(eastWall==false) //if there is a wall on the right side of the car
  {
    matrix[x][y-1]=matrix[x][y-1]|east;////update the 2D array with a 1 to indicate the existance of a wall on right side of the car
  }
  if(westWall==false)//if there isa wall on the left side of the car
  {
    matrix[x][y+1]=matrix[x][y+1]|west;//update the 2D array with a 1 to indicate the existance of a wall on the left side of the car
  }
  
  
}
int MapAlgorithm::floodFill()
{
  int leastValue=100; //keeps track of the least value neighbouring cell
  int newX=x;  //keeps track of the horizontal position of the least value neighbouting cell
  int newY=y; //keeps track of the vertical position of the least value neighbouting cell
  bool change=true;//a variable to check when to end the flood fill process
  while(change)
  {
    for(int i=0;i<4;i++) //
    {
      for(int j=0;j<4;j++)
      {
         if(newMatrix[i][j]!=0)//if the current cell is not the goal cell
        {
          if(newMatrix[i+1][j]<leastValue)//if the front neighbour is closer to the goal 
          {
             leastValue=newMatrix[i+1][j];//store the distance value of the front neighbour
          }
          if(newMatrix[i][j+1]<leastValue)//if the left neighbouring cell is closest to the goal
          {
             leastValue=newMatrix[i][j+1];//update/overwrite the distance value of the left side neighbour 
          }
          if(newMatrix[i][j]!=leastValue+1)
          {
              newMatrix[i][j]=leastValue+1; //set the cirrent cells distance value to one more than the value of the closest neighbour
          }
          else{
            change=false;
          }
        }
    }
   }
  }
}
void MapAlgorithm::motionAlgorithm()
{
    scanCell(); //remove out of bound positions 
    addWall();  //declare walls within the cell the car is currently in
    floodFill(); // update the distance values of the cells to the goal cel
    int val=100;  //a value to keep track of the least value neighbouring cell
    if(northWall==false)//if there is no wall infront of the car
    {
      if(newMatrix[x+1][y]<val) //if the cell infront of the car has a lower value  
      {
        heading=270;  //set the angular value to a forward motion
      }
    }
    if(southWall==false)//if there is no wall behind the car
    {
      if(newMatrix[x-1][y]<val)//if the cell behind the car has a lower value
      {
        heading=90; //set the angular value to a backward motion
      }
    }
    if(eastWall==false) //if there is a wall on the right side of the car
    {
      if(newMatrix[x][y-1]<val)//if the cell on the right side of the car has a lower value
      {
        heading=0;//set the angular value to a right turn motion
      }
    }
    if(westWall==false)//if there is a wall on the left side of the car
    {
      if(newMatrix[x][y+1]<val)//if the cell on the left side of the car has a lower value
      {
        heading=180;//set the angular value to a left turn motion
      }
    }
    
}

void Car::updatePosition()
{
  Serial.print("Angle");
  Serial.println(mapAlgorithm.heading);
  mapAlgorithm.x=mapAlgorithm.x-sin(mapAlgorithm.heading*M_PI/180);
  mapAlgorithm.y=mapAlgorithm.y-cos(mapAlgorithm.heading*M_PI/180);

  Serial.print("Current position:  ");
  Serial.println(mapAlgorithm.x);
  Serial.print("and ");
  Serial.println(mapAlgorithm.y);

  if(mapAlgorithm.x==goalX && mapAlgorithm.y==goalY)
  {
    carState=0;
  }
  else
  {
    carState=1;
  }
}
