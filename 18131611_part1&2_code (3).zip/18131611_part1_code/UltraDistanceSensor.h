#include<Servo.h>
#include "Arduino.h"

#define Echo  A4 //Input pin to receive from the environment
#define Trig  A5 //Ouput pin to produce vibrations to the environment 

//constants to define different directios
const int LEFT=1;
const int FORWARD =2;
const int RIGHT =3;
const int BACK =4;

class UltraDistanceSensor
{
  Servo myServo; //used for alligning the utradistance sensors in different directions
  int rightDistance = 0, leftDistance = 0, middleDistance = 0; //holds measurements from different directions
  public:
    void attachServo();  //assigns the servo to a specific pin
    int measureDistance(); //calculates the ditsances between the car and an obstacle
    int scanDistance(); //compares distances from different directions and returns the longest
};
