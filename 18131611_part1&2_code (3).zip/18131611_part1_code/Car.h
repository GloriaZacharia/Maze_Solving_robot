#include "Movement.h"
#include "UltraDistanceSensor.h"
#include "LineTracking.h"
#include <math.h>

class Car{
  Movement carMovement;
  UltraDistanceSensor ultraDistanceSensor;
  LineTracking lineTracking;
  int carState=1;  //used to keep track of wether or not the car has reached to the goal
  int x=0;   //horizontal position of thr car
  int y=0;    //vertical position of the car
  int goalX=3;  //horizontal position of the goal cell
  int goalY=3;  //vertical position of the goal cell
  int heading=0;  //angular value of the direction that the car is to take
  
  public:
    void setup();
    void run();
    void updatePosition();  // a method used to update the car's position when it moves to a new cell and keep track of wether the car has reached the goal
  
};
