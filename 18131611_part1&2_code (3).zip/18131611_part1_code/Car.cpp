
#include "Car.h"


void Car::run()
{
  int dir=lineTracking.detectLine();  //Read the resistance values of the line tracking modules
  if(dir==LT_M) //if middle module is signaled
  {
    carMovement.forward(); //move the car forward
  }
  else if(dir==LT_R) {  //if right module is signaled
    carMovement.right();    //turn the car to the right                 
    while(LT_R);         //keep turning the car to the right until the right module is can no longer see the black line
  }   
  else if(dir==LT_L) {  //if the left moduke is signaled
    carMovement.left();  //turn the car to the left
    while(LT_L);          //keep turning the car to the left until the left module can no longer see the line
  }
  else if(dir ==JUNCTION)  //if all the module can see the black line
  {
    carMovement.stop(); //stop the car
    delay(500);
    carMovement.forward();  //move the car a bit forward so as to make an accurate turn when needed
    delay(100);
    carMovement.stop();  //stop the car
    delay(360);
    ultraDistanceSensor.attachServo(); //assign the servo to a apeific pin
    int len = ultraDistanceSensor.scanDistance();  //calculate the distances from either directions
    if(len==RIGHT)  //if right turn signal is received
    {
      heading=0;   // set the angular value for a right turn
      carMovement.right(); //turn the car to the right
      delay(500);  //pause for some time
    }
    else if(len==LEFT) //otherwise if the left turn signal is recieved
    {
      heading=180;  //update the angular value for a left turn
      carMovement.left(); //turn the car to the left
      delay(600);
    }
    else if(len==FORWARD) //otherwise if the forward motion signal is recieved 
    {
      heading=270;   //set the angular value for a forward motion
      carMovement.forward(); //move the car forward
    }
    else{  //if neither left, right ot forward motion signals are received
      heading=90;  //set the angular value for a backward motion
      carMovement.back(); //move the car back
      delay(360);
    }
    updatePosition();   //recalculate the car's new positio  and update it
    if(carState==0)  //if the foal is reached
    {
       while(true) //stop the car and end the path finding
       {
          carMovement.stop();
       }
    }
  }  
  
}
void Car::setup()
{
    Serial.begin(9600); 
    pinMode(IN1,OUTPUT);//before using io pin, pin mode must be set first 
    pinMode(IN2,OUTPUT);
    pinMode(IN3,OUTPUT);
    pinMode(IN4,OUTPUT);
    pinMode(ENA,OUTPUT);
    pinMode(ENB,OUTPUT);

    pinMode(LT_R,INPUT);
    pinMode(LT_M,INPUT);
    pinMode(LT_L,INPUT);
    
    pinMode(Echo, INPUT);    
    pinMode(Trig, OUTPUT); 
}
void Car::updatePosition()
{
  Serial.print("Angle");
  Serial.println(heading);
  x=x-sin(heading*M_PI/180); //calculate the new horizontal position
  y=y-cos(heading*M_PI/180);//calculate the new vertical position

  Serial.print("Current position:  ");
  Serial.println(x);
  Serial.print("and ");
  Serial.println(y);

  if(x==goalX && y==goalY) //if the new position is the position of the goal cell
  {
    carState=0;  //update the value that indicates the car has reached the goal
  }
  else
  {
    carState=1;
  }
  
}
