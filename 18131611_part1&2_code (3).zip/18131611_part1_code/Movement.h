#include "Arduino.h"

//Output pins used to control the motors
#define ENA 5 
#define ENB 6

//pins to control the left wheel
#define IN1 7
#define IN2 8

//pins to control the right wheel
#define IN3 9
#define IN4 11

class Movement{
  int carSpeed= 150; //defines the amout of voltage to apply to the motors when the car is moving forward or back ward
  int turningSpeed =500;//defines the amount of voltage to apply to the motors when the car is making a turn
  public:
    /*methods used to control the car's motion*/
    void back();  
    void forward();
    void left();
    void right();
    void stop(); 
};
