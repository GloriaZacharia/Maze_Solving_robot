#include "LineTracking.h"

int LineTracking::detectLine()
{
  if((!LT_L)&&(LT_M)&&(!LT_R))//if only the middle module detects the line
  {
    return LT_M; //signal a forward motion
  }
  if((LT_L) && (LT_M) && (!LT_R)){ //if the midle and the left modules alone detect the line 
    return LT_L;           //signal a left motion
  }
  if((LT_L) && (!LT_M)&& (!LT_R)) //if the left module alone detects the black line
  {
    return LT_L;              //signal a left motion
  }
  if((!LT_L) && (LT_M) &&(LT_R))   //if the middle and right modules alone detect the line
  {
    return LT_R;                //signal a right motion
  }
  if((!LT_L) && (!LT_M) && (LT_R))  //if the right module alone detects the line
  {
    return LT_R;          //signal a right motion
  }
  if((LT_L)&&(LT_M)&&(LT_R)) //if all the modules detect the line
  {
    return JUNCTION;   //signal that the car is at a junction
  }
}
