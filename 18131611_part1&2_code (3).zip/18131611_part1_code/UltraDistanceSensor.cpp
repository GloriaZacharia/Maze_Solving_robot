#include "UltraDistanceSensor.h"


int UltraDistanceSensor::measureDistance()
{
  digitalWrite(Trig, LOW);   
  delayMicroseconds(2);
  digitalWrite(Trig, HIGH);  
  delayMicroseconds(20);
  digitalWrite(Trig, LOW);   
  float Fdistance = pulseIn(Echo, HIGH); //calculate the time taken for the sound waves to be received back from the environment
  Serial.print("Time=");
  Serial.println(Fdistance); 
  Fdistance= Fdistance*(0.034/2);  //calculate the distance between the car and an obstacle by multiplying the speed and half the total time taken  
  return (int)Fdistance;   //cast the distance to an integer and return it
}
int UltraDistanceSensor::scanDistance()
{
    //delay(500);
    myServo.write(75);  //setservo position according to scaled value
    delay(500); 
    middleDistance = measureDistance(); //calculate the middle distance between the car and any obstacle infront of it
    Serial.print("Middle distance=");
    Serial.println(middleDistance);

    if(middleDistance <= 20) //If there is an obstacle infront of it
    {     
      //stop();
      delay(500); //pause for some time
      myServo.write(8); //align the utra distance sensors to the right hand side of the car       
      delay(1000);     //wait for sme time
      rightDistance = measureDistance(); //calculate the distance between the car and any obstacle on the right hand side
      Serial.print("Right distance=");  //display the right hand side distance
      Serial.println(rightDistance);
      
      delay(500);
      myServo.write(75);  //align the ultra distance sensors straight ahead   
      delay(1000);                                                  
      myServo.write(150);  //align the ultra distance sensors to the left of the car            
      delay(1000); 
      leftDistance = measureDistance(); //calculate the distance between the car and any obstacle on the left hand side
      Serial.print("Left distance=");
      Serial.println(leftDistance);

      delay(500);
      myServo.write(75);   //align the ultra distance sensors straight ahead           
      delay(1000);
      if(rightDistance > leftDistance) //if the right ditance is more than the left one
      {
        if(rightDistance <= 20) //if there is an obstacle on the right side too
        {
          return BACK; // signal a backward motion
        }
        else{ //if there is no obstacle
         return RIGHT; //signal a right turn
        }
        
      }
      else if(rightDistance < leftDistance) //otherwise if right distance is less that the left distance
      {
        if(leftDistance <= 20) //if there is an obstacle to the left hand side too
        {
          return BACK;  //signal a back ward motion
        }
        else{  //if there is no obstacle to the left side
          return LEFT; //signal a left motion
        }
      }
      else { 
        return BACK;
      }
    }
    else { //If there id no obstacle straight ahead of the car
        return FORWARD; //signal a forward motion
      }  
                
}

void UltraDistanceSensor::attachServo()
{
  myServo.attach(3);
}
